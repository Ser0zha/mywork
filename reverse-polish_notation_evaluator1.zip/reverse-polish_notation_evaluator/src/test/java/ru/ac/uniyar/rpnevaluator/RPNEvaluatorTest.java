package ru.ac.uniyar.rpnevaluator;

import org.junit.jupiter.api.Test;

import java.util.EmptyStackException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class RPNEvaluatorTest {

    /**
     * Тест сложения двух чисел
     * Действие: вычисление выражения "2 3 +"
     * Ожидаемый результат: 5
     */
    @Test
    void additionShouldReturnCorrectResult() {
        String[] tokens = {"2", "3", "+"};
        
        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(5);
    }

    /**
     * Тест вычитания двух чисел
     * Действие: вычисление выражения "5 3 -"
     * Ожидаемый результат: 2
     */
    @Test
    void subtractionShouldReturnCorrectResult() {
        String[] tokens = {"5", "3", "-"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(2);
    }

    /**
     * Тест умножения двух чисел
     * Действие: вычисление выражения "2 4 *"
     * Ожидаемый результат: 8
     */
    @Test
    void multiplicationShouldReturnCorrectResult() {
        String[] tokens = {"2", "4", "*"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(8);
    }

    /**
     * Тест деления двух чисел
     * Действие: вычисление выражения "6 2 /"
     * Ожидаемый результат: 3
     */
    @Test
    void divisionShouldReturnCorrectResult() {
        String[] tokens = {"6", "2", "/"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(3);
    }

    /**
     * Тест комплексного выражения
     * Действие: вычисление выражения "5 1 2 + 4 * + 3 -"
     * Ожидаемый результат: 14
     */
    @Test
    void complexExpressionShouldEvaluateCorrectly() {
        String[] tokens = {"5", "1", "2", "+", "4", "*", "+", "3", "-"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(14);
    }

    /**
     * Тест выражения с одним числом
     * Действие: вычисление выражения "42"
     * Ожидаемый результат: 42
     */
    @Test
    void singleNumberShouldReturnItself() {
        String[] tokens = {"42"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(42);
    }

    /**
     * Тест деления на ноль
     * Действие: вычисление выражения "1 0 /"
     * Ожидаемый результат: выбрасывается ArithmeticException
     */
    @Test
    void divisionByZeroShouldThrowException() {
        String[] tokens = {"1", "0", "/"};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(ArithmeticException.class);
    }

    /**
     * Тест недопустимого оператора
     * Действие: вычисление выражения ["1", "2", "%"]
     * Ожидаемый результат: NumberFormatException
     */
    @Test
    void invalidOperatorShouldThrowException() {
        String[] tokens = {"1", "2", "%"};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(NumberFormatException.class)
                .hasMessageContaining("For input string: \"%\"");
    }

    /**
     * Тест недостаточного количества операндов
     * Действие: вычисление выражения "1 +"
     * Ожидаемый результат: выбрасывается EmptyStackException
     */
    @Test
    void insufficientOperandsShouldThrowException() {
        String[] tokens = {"1", "+"};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(EmptyStackException.class);
    }

    /**
     * Тест нехватки операндов для оператора
     * Действие: вычисление выражения ["+"]
     * Ожидаемый результат: EmptyStackException
     */
    @Test
    void singleOperatorShouldThrowEmptyStackException() {
        String[] tokens = {"+"};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(EmptyStackException.class);
    }

    /**
     * Тест лишних операндов
     * Действие: вычисление выражения "1 2 3 +"
     * Ожидаемый результат: выбрасывается IllegalArgumentException
     */
    @Test
    void extraOperandsShouldThrowException() {
        String[] tokens = {"1", "2", "3", "+"};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Not a single element left in a stack after evaluation");
    }

    /**
     * Тест нечислового токена
     * Действие: вычисление выражения ["one", "2", "+"]
     * Ожидаемый результат: NumberFormatException
     */
    @Test
    void nonNumericTokenShouldThrowException() {
        String[] tokens = {"one", "2", "+"};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(NumberFormatException.class)
                .hasMessageContaining("For input string: \"one\"");
    }

    /**
     * Тест пустого ввода
     * Действие: вычисление пустого массива
     * Ожидаемый результат: выбрасывается IllegalArgumentException
     */
    @Test
    void emptyInputShouldThrowException() {
        String[] tokens = {};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(IllegalArgumentException.class);
    }

    /**
     * Тестирование порядка операций (приоритетов)
     * Действие: вычисление выражения "2 3 * 4 +" (эквивалентно 2*3 + 4)
     * Ожидаемый результат: 10
     */
    @Test
    void operatorPrecedenceShouldBeCorrect() {
        String[] tokens = {"2", "3", "*", "4", "+"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(10);
    }

    /**
     * Тестирование отрицательных чисел
     * Действие: вычисление выражения "3 -2 *"
     * Ожидаемый результат: -6
     */
    @Test
    void negativeNumbersShouldBeSupported() {
        String[] tokens = {"3", "-2", "*"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(-6);
    }

    /**
     * Тест деления нуля на число
     * Действие: вычисление выражения ["0", "5", "/"]
     * Ожидаемый результат: 0
     */
    @Test
    void zeroDividedByNumber() {
        String[] tokens = {"0", "5", "/"};

        assertThat(RPNEvaluator.evaluate(tokens))
                .isEqualTo(0);
    }

    /**
     * Тест с пустым оператором, который также является недопустимым.
     * Ожидаемый результат: выбрасывается IllegalArgumentException с сообщением "Invalid operator".
     */
    @Test
    void emptyOperatorShouldThrowException() {
        String[] tokens = {"3", "4", ""};

        assertThatThrownBy(() -> RPNEvaluator.evaluate(tokens))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Invalid operator");
    }
}
