import numpy as np
import pandas as pd
from PySide6.QtCharts import (QChart, QChartView, QLineSeries, QScatterSeries,
                              QBarSeries, QBarSet, QPieSeries)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPainter, QColor
from PySide6.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget,
                               QVBoxLayout, QLabel, QMessageBox)

PATH_TREE = 'trees.csv'
PATH_HURRICANES = "hurricanes.csv"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Визуализация данных")
        self.setGeometry(100, 100, 1000, 800)

        self.tabs = QTabWidget()

        # Создаем вкладки
        self.create_sin_cos_tab()
        self.create_trees_tab()
        self.create_hurricanes_tab()

        self.setCentralWidget(self.tabs)

    def create_sin_cos_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        # График синуса
        sin_chart = QChart()
        sin_chart.setTitle("График синуса")

        sin_series = QLineSeries()
        sin_series.setName("sin(x)")

        x = np.linspace(0, 2 * np.pi, 30)
        y_sin = np.sin(x)

        for i in range(len(x)):
            sin_series.append(float(x[i]), y_sin[i])

        sin_chart.addSeries(sin_series)
        sin_chart.createDefaultAxes()

        sin_chart_view = QChartView(sin_chart)
        sin_chart_view.setRenderHint(QPainter.RenderHint.Antialiasing)

        # График косинуса
        cos_chart = QChart()
        cos_chart.setTitle("График косинуса")

        cos_series = QLineSeries()
        cos_series.setName("cos(x)")
        cos_series.setColor(QColor("orange"))

        y_cos = np.cos(x)

        for i in range(len(x)):
            cos_series.append(float(x[i]), y_cos[i])

        cos_chart.addSeries(cos_series)
        cos_chart.createDefaultAxes()

        cos_chart_view = QChartView(cos_chart)
        cos_chart_view.setRenderHint(QPainter.RenderHint.Antialiasing)

        layout.addWidget(sin_chart_view)
        layout.addWidget(cos_chart_view)
        tab.setLayout(layout)
        self.tabs.addTab(tab, "Синус и косинус")

    def create_trees_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        try:
            # Загрузка данных о деревьях
            trees = pd.read_csv(PATH_TREE)

            # Проверка структуры данных
            if not all(col in trees.columns for col in ['Girth', 'Height', 'Volume']):
                raise ValueError("Файл trees.csv имеет неверную структуру")

            # Точечная диаграмма: Girth vs Height
            scatter_chart = QChart()
            scatter_chart.setTitle("Обхват vs Высота деревьев")

            scatter_series = QScatterSeries()
            scatter_series.setName("Деревья")
            scatter_series.setMarkerSize(10)

            for _, row in trees.iterrows():
                scatter_series.append(row["Girth"], row["Height"])

            scatter_chart.addSeries(scatter_series)
            scatter_chart.createDefaultAxes()

            scatter_view = QChartView(scatter_chart)
            scatter_view.setRenderHint(QPainter.RenderHint.Antialiasing)

            # Столбчатая диаграмма: средний Volume по Girth (округленный)
            bar_chart = QChart()
            bar_chart.setTitle("Средний объем по обхвату")

            bar_series = QBarSeries()

            trees["Girth_rounded"] = trees["Girth"].round().astype(int)
            grouped = trees.groupby("Girth_rounded")["Volume"].mean()

            for girth, volume in grouped.items():
                bar_set = QBarSet(str(girth))
                bar_set.append(volume)
                bar_series.append(bar_set)

            bar_chart.addSeries(bar_series)
            bar_chart.createDefaultAxes()

            bar_view = QChartView(bar_chart)
            bar_view.setRenderHint(QPainter.RenderHint.Antialiasing)

            layout.addWidget(scatter_view)
            layout.addWidget(bar_view)

        except Exception as e:
            self.show_error_message(layout, str(e), "Ошибка загрузки данных о деревьях")

        tab.setLayout(layout)
        self.tabs.addTab(tab, "Деревья")

    def create_hurricanes_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        try:
            # Загрузка данных об ураганах
            hurricanes = pd.read_csv(PATH_HURRICANES)

            # Проверка структуры данных
            required_columns = ['Month', 'Average']
            year_columns = [col for col in hurricanes.columns if col not in required_columns]

            if not all(col in hurricanes.columns for col in required_columns) or len(year_columns) == 0:
                raise ValueError("Файл hurricanes.csv имеет неверную структуру")

            # Круговая диаграмма для 2007 года
            if '2007' in hurricanes.columns:
                pie_2007 = QChart()
                pie_2007.setTitle("Ураганы 2007 года по месяцам")

                pie_series_2007 = QPieSeries()

                # Находим максимальное значение для выделения
                max_value = hurricanes['2007'].max()

                for _, row in hurricanes.iterrows():
                    if row['2007'] > 0:
                        slice_ = pie_series_2007.append(row['Month'], row['2007'])
                        if row['2007'] == max_value:
                            slice_.setExploded(True)
                            slice_.setLabelVisible(True)

                pie_2007.addSeries(pie_series_2007)

                pie_view_2007 = QChartView(pie_2007)
                pie_view_2007.setRenderHint(QPainter.RenderHint.Antialiasing)

                layout.addWidget(pie_view_2007)
            else:
                raise ValueError("Отсутствуют данные за 2007 год")

            # Круговая диаграмма по годам
            pie_years = QChart()
            pie_years.setTitle("Ураганы по годам")

            pie_series_years = QPieSeries()

            yearly_totals = hurricanes[year_columns].sum()

            # Находим минимальное значение для выделения
            min_value = yearly_totals.min()

            for year, total in yearly_totals.items():
                slice_ = pie_series_years.append(year, total)
                if total == min_value:
                    slice_.setExploded(True)
                    slice_.setLabelVisible(True)

            pie_years.addSeries(pie_series_years)

            pie_view_years = QChartView(pie_years)
            pie_view_years.setRenderHint(QPainter.RenderHint.Antialiasing)

            layout.addWidget(pie_view_years)

        except Exception as e:
            self.show_error_message(layout, str(e), "Ошибка загрузки данных об ураганах")

        tab.setLayout(layout)
        self.tabs.addTab(tab, "Ураганы")

    def show_error_message(self, layout, error, title):
        error_label = QLabel(f"Ошибка: {error}")
        error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(error_label)

        # Показываем сообщение об ошибке
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setText(error)
        msg.setWindowTitle(title)
        msg.exec()


if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec()
